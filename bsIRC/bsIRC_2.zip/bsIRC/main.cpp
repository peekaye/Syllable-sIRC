#include "application.h"

int main( int argc, char *argv[] )
{
	App* pcApp = new App();
	pcApp->Run();
	return( 0 );
}
