#!/bin/sh
export PATH=$PATH:/usr/bin:/atheos/autolnk/bin
cd '/boot/atheos/home/root/bsIRC'
make
echo Finished - Press return to close this window
read
