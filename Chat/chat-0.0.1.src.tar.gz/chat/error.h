#ifndef __ERROR_H
#define __ERROR_H


#define OK   1
#define FAIL 0



#endif




