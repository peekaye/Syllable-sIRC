#include "main.h"
using namespace os;

int main(int argc, char** argv)
{
    string cString = (string) getenv("HOME");
    mkdir ((cString +  (string)"/People").c_str(),0700);

    AddApp* thisApp = new AddApp(argc, argv);
    thisApp->Run();
    return 0;
}





