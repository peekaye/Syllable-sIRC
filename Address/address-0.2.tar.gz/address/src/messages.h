#ifndef MESSAGES_H
#define MESSAGES_H

enum
{
    ID_QUIT,
    ID_APP_SET,
    ID_APP_ABOUT,
    ID_FILE_OPEN,
    ID_COUNTRY,
    ID_CLOSE_TAB,
    ID_NEW_TAB,
    ID_SAVE_TAB
};
#endif

